DICOCH Starter Kit
===================

Contents
--------
1. README_DICOCH.txt   — this file
2. example_dicoch.dcm  — minimal placeholder DICOM file
3. tag_template_base.xlsx — base Excel template for authoring custom DICOCH tags

The provided DICOM is a placeholder containing only the 128-byte preamble
and 'DICM' marker. Generate a full sample using the DICOCH DICOM Converter
once your tag values are ready.

Author
------
Song Jung‑il · National Research Institute of Cultural Heritage ssong85@korea.kr

